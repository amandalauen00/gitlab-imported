#include <iostream>
using namespace std;

int main()
{
    cout << "Hello World!" << endl;
    cout << "Hello Gitlab!!" << endl;

    return 0;
}