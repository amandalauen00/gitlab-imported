#include <cctype>
using namespace std;

int recCmp (char* lhs, char* rhs, int index);

void fixTitle (char* title, int index);


#pragma once
