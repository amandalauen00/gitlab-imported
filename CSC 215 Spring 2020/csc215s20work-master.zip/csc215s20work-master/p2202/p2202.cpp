#define CATCH_CONFIG_MAIN
#include "..\catch.hpp"
#include "recCstring.h"

using namespace std;