#ifndef __GPIO__H
#define __GPIO__H

#include <iostream>
using namespace std;

void accelGPIO ( int &gpio_info, int adjust_num );

#endif
